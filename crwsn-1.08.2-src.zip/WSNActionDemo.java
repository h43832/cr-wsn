public class WSNActionDemo implements WSNAction{
    public void startAction(WSN wsn,String dataSource,String data){
        System.out.println("Hello world. This is a WSNAction demo class.");
    }
}