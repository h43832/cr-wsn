public interface WSNDataGenerator {
  public String getData();
}