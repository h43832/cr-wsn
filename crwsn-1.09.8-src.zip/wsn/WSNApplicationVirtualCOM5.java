package wsn;

/**
 *
 * @author 850136
 */
public class WSNApplicationVirtualCOM5 extends WSNApplicationVirtualCOM{

}