package wsn;

/**
 *
 * @author 850136
 */
public class WSNRedirector3 extends WSNRedirector{

}