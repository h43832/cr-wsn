package wsn;

/**
 *
 * @author 850136
 */
public class WSNLineChart2 extends WSNLineChart{

}