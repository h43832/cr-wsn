package wsn;

/**
 *
 * @author 850136
 */
public class WSNRedirector4 extends WSNRedirector{

}