import java.awt.Color;
import java.util.*;
public class WSNDisplayProcessor extends Thread{
  WSN wsn;
  Vector waitV=new Vector();
  long longWaitTime=31536000000L;
  boolean isSleep=false; 

  public WSNDisplayProcessor(WSN wsn){
    this.wsn=wsn;
  }
  public void run(){
    while(true){
        while(waitV.size()>0){

          DataClass dataClass=(DataClass)waitV.get(0);

          wsn.textPaneAppend( dataClass.data, dataClass.fontColor, dataClass.fontSize);
          waitV.remove(0);
        }
        wsn.jTextPane1.setCaretPosition(wsn.jTextPane1.getDocument().getLength());
        try{
            isSleep=true;
            Thread.sleep(longWaitTime);
            isSleep=false;
        }catch(InterruptedException e){
            isSleep=false;
        }
    }
  }
  public void setData(String data,Color fontColor,int fontSize){

    DataClass dataClass=new DataClass(data,fontColor,fontSize);
    waitV.add(dataClass);
    if(isSleep) this.interrupt();
}
   public class DataClass{
   String data;
   int fontSize;
   Color fontColor;
   public DataClass(String data,Color fontColor,int fontSize){
     this.data=data;
     this.fontColor=fontColor;
     this.fontSize=fontSize;
   }
 }
}