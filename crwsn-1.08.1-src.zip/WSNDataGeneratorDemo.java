public class WSNDataGeneratorDemo implements WSNDataGenerator{
  public String getData(){
    return ""+(Math.random() * 10000.0);
  }
}