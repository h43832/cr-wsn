import java.awt.*;
import java.util.*;
import infinity.client.*;
import javax.swing.*;
import javax.swing.text.*;

import java.io.*;

public class WSNNodesManager extends javax.swing.JFrame {
   WSN wsn;

   ResourceBundle bundle2;
   public String currentItemData3[]={},currentViewId3="",currentViewId3_1="",currentViewId3_2="",currentViewId3_3="",
           currentInnerMemberId3="",sep=""+(char)0,pid="",lastId3="",lastId3_1="",lastId3_2="",lastId3_3="",currentViewStatus3[]=null;
   public DefaultListModel listModel3=new DefaultListModel(),connListModel=new DefaultListModel(), skPortListModel=new DefaultListModel(), srPortListModel=new DefaultListModel();
    public WSNNodesManager(WSN wsn,String pid){
        initComponents();
        bundle2 = java.util.ResourceBundle.getBundle("Bundle"); 
        this.wsn=wsn;

        int width=Toolkit.getDefaultToolkit().getScreenSize().width;
        int h=Toolkit.getDefaultToolkit().getScreenSize().height-20;

        int w2=(width * 90000)/100000;
        int h2=(h * 90000)/100000;

        setSize(w2,h2);

        setLocation((width-w2)/2,(h-h2)/2);
        setIconImage(Toolkit.getDefaultToolkit().createImage("apps"+File.separator+"cr-wsn"+File.separator+"crtc_logo7_transparent.gif"));
    }

    @SuppressWarnings("unchecked")

    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jList3 = new javax.swing.JList();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        socketPortList = new javax.swing.JList();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        connectionList = new javax.swing.JList();
        jLabel2 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jPanel7 = new javax.swing.JPanel();
        jButton4 = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jPanel8 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        serialPortList = new javax.swing.JList();
        jPanel4 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jComboBox5 = new javax.swing.JComboBox();
        jLabel14 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox();
        jLabel15 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox();
        jComboBox1 = new javax.swing.JComboBox();
        jComboBox4 = new javax.swing.JComboBox();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        java.util.ResourceBundle bundle = java.util.ResourceBundle.getBundle("Bundle"); 
        setTitle(bundle.getString("WSNNodesManager.title")); 
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jList3.setModel(listModel3);
        jList3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jList3MouseClicked(evt);
            }
        });
        jList3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jList3KeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jList3);

        getContentPane().add(jScrollPane1, java.awt.BorderLayout.WEST);

        jPanel1.setLayout(new java.awt.GridLayout(2, 0));

        jPanel2.setBackground(new java.awt.Color(255, 255, 204));
        jPanel2.setLayout(null);

        socketPortList.setFont(socketPortList.getFont().deriveFont(socketPortList.getFont().getSize()+6f));
        socketPortList.setModel(skPortListModel);
        socketPortList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                socketPortListMouseClicked(evt);
            }
        });
        socketPortList.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                socketPortListKeyReleased(evt);
            }
        });
        jScrollPane2.setViewportView(socketPortList);

        jPanel2.add(jScrollPane2);
        jScrollPane2.setBounds(40, 40, 90, 230);

        jLabel1.setBackground(new java.awt.Color(153, 153, 255));
        jLabel1.setFont(jLabel1.getFont().deriveFont(jLabel1.getFont().getSize()+4f));
        jLabel1.setText(bundle.getString("WSNNodesManager.jLabel1.text")); 
        jLabel1.setOpaque(true);
        jPanel2.add(jLabel1);
        jLabel1.setBounds(40, 13, 90, 30);

        connectionList.setFont(connectionList.getFont().deriveFont(connectionList.getFont().getSize()+6f));
        connectionList.setModel(connListModel);
        connectionList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                connectionListMouseClicked(evt);
            }
        });
        connectionList.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                connectionListKeyReleased(evt);
            }
        });
        jScrollPane3.setViewportView(connectionList);

        jPanel2.add(jScrollPane3);
        jScrollPane3.setBounds(140, 40, 90, 230);

        jLabel2.setBackground(new java.awt.Color(204, 255, 255));
        jLabel2.setFont(jLabel2.getFont().deriveFont(jLabel2.getFont().getSize()+4f));
        jLabel2.setText(bundle.getString("WSNNodesManager.jLabel2.text")); 
        jLabel2.setOpaque(true);
        jPanel2.add(jLabel2);
        jLabel2.setBounds(140, 13, 90, 30);

        jPanel6.setLayout(null);

        jButton1.setFont(jButton1.getFont().deriveFont(jButton1.getFont().getSize()+4f));
        jButton1.setText(bundle.getString("WSNNodesManager.jButton1.text")); 
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel6.add(jButton1);
        jButton1.setBounds(10, 170, 220, 29);

        jLabel19.setFont(jLabel19.getFont().deriveFont(jLabel19.getFont().getSize()+6f));
        jLabel19.setText(bundle.getString("WSNNodesManager.jLabel19.text")); 
        jPanel6.add(jLabel19);
        jLabel19.setBounds(10, 20, 80, 23);

        jLabel21.setFont(jLabel21.getFont().deriveFont(jLabel21.getFont().getSize()+6f));
        jLabel21.setText(bundle.getString("WSNNodesManager.jLabel21.text")); 
        jPanel6.add(jLabel21);
        jLabel21.setBounds(100, 20, 70, 23);

        jLabel22.setFont(jLabel22.getFont().deriveFont(jLabel22.getFont().getSize()+2f));
        jLabel22.setText(bundle.getString("WSNNodesManager.jLabel22.text")); 
        jPanel6.add(jLabel22);
        jLabel22.setBounds(10, 80, 180, 18);

        jButton5.setFont(jButton5.getFont().deriveFont(jButton5.getFont().getSize()+6f));
        jButton5.setText(bundle.getString("WSNNodesManager.jButton5.text")); 
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel6.add(jButton5);
        jButton5.setBounds(10, 123, 220, 30);

        jLabel24.setFont(jLabel24.getFont().deriveFont(jLabel24.getFont().getSize()+6f));
        jLabel24.setText(bundle.getString("WSNNodesManager.jLabel24.text")); 
        jPanel6.add(jLabel24);
        jLabel24.setBounds(10, 50, 170, 23);

        jLabel25.setFont(jLabel25.getFont().deriveFont(jLabel25.getFont().getSize()+6f));
        jLabel25.setText(bundle.getString("WSNNodesManager.jLabel25.text")); 
        jPanel6.add(jLabel25);
        jLabel25.setBounds(190, 50, 30, 23);

        jTextField3.setFont(jTextField3.getFont().deriveFont(jTextField3.getFont().getSize()+6f));
        jTextField3.setText(bundle.getString("WSNNodesManager.jTextField3.text")); 
        jPanel6.add(jTextField3);
        jTextField3.setBounds(190, 80, 40, 20);

        jPanel2.add(jPanel6);
        jPanel6.setBounds(250, 40, 240, 230);

        jPanel7.setLayout(null);

        jButton4.setFont(jButton4.getFont().deriveFont(jButton4.getFont().getSize()+4f));
        jButton4.setText(bundle.getString("WSNNodesManager.jButton4.text")); 
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel7.add(jButton4);
        jButton4.setBounds(20, 90, 220, 29);

        jLabel20.setFont(jLabel20.getFont().deriveFont(jLabel20.getFont().getSize()+6f));
        jLabel20.setText(bundle.getString("WSNNodesManager.jLabel20.text")); 
        jPanel7.add(jLabel20);
        jLabel20.setBounds(20, 20, 110, 20);

        jTextField1.setFont(jTextField1.getFont().deriveFont(jTextField1.getFont().getSize()+6f));
        jTextField1.setText(bundle.getString("WSNNodesManager.jTextField1.text")); 
        jPanel7.add(jTextField1);
        jTextField1.setBounds(130, 20, 80, 30);

        jLabel23.setFont(jLabel23.getFont().deriveFont(jLabel23.getFont().getSize()+4f));
        jLabel23.setText(bundle.getString("WSNNodesManager.jLabel23.text")); 
        jPanel7.add(jLabel23);
        jLabel23.setBounds(20, 50, 200, 30);

        jTextField2.setFont(jTextField2.getFont().deriveFont(jTextField2.getFont().getSize()+6f));
        jTextField2.setText(bundle.getString("WSNNodesManager.jTextField2.text")); 
        jPanel7.add(jTextField2);
        jTextField2.setBounds(220, 50, 40, 29);

        jPanel2.add(jPanel7);
        jPanel7.setBounds(500, 140, 280, 130);

        jPanel8.setLayout(null);

        jLabel26.setFont(jLabel26.getFont().deriveFont(jLabel26.getFont().getSize()+6f));
        jLabel26.setText(bundle.getString("WSNNodesManager.jLabel26.text")); 
        jPanel8.add(jLabel26);
        jLabel26.setBounds(10, 10, 150, 23);

        jLabel27.setFont(jLabel27.getFont().deriveFont(jLabel27.getFont().getSize()+6f));
        jLabel27.setText(bundle.getString("WSNNodesManager.jLabel27.text")); 
        jPanel8.add(jLabel27);
        jLabel27.setBounds(170, 10, 40, 23);

        jButton6.setFont(jButton6.getFont().deriveFont(jButton6.getFont().getSize()+4f));
        jButton6.setText(bundle.getString("WSNNodesManager.jButton6.text")); 
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel8.add(jButton6);
        jButton6.setBounds(10, 40, 230, 29);

        jPanel2.add(jPanel8);
        jPanel8.setBounds(500, 40, 280, 80);

        jPanel1.add(jPanel2);

        jPanel3.setBackground(new java.awt.Color(204, 255, 255));
        jPanel3.setLayout(null);

        jLabel3.setBackground(new java.awt.Color(153, 153, 255));
        jLabel3.setFont(jLabel3.getFont().deriveFont(jLabel3.getFont().getSize()+4f));
        jLabel3.setText(bundle.getString("WSNNodesManager.jLabel3.text")); 
        jLabel3.setOpaque(true);
        jPanel3.add(jLabel3);
        jLabel3.setBounds(40, 13, 90, 30);

        serialPortList.setFont(serialPortList.getFont().deriveFont(serialPortList.getFont().getSize()+6f));
        serialPortList.setModel(srPortListModel);
        serialPortList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                serialPortListMouseClicked(evt);
            }
        });
        serialPortList.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                serialPortListKeyReleased(evt);
            }
        });
        jScrollPane4.setViewportView(serialPortList);

        jPanel3.add(jScrollPane4);
        jScrollPane4.setBounds(40, 40, 90, 210);

        jPanel4.setLayout(null);

        jLabel13.setFont(jLabel13.getFont().deriveFont(jLabel13.getFont().getSize()+6f));
        jLabel13.setText(bundle.getString("WSNNodesManager.jLabel13.text")); 
        jPanel4.add(jLabel13);
        jLabel13.setBounds(140, 140, 50, 20);

        jLabel12.setFont(jLabel12.getFont().deriveFont(jLabel12.getFont().getSize()+6f));
        jLabel12.setText(bundle.getString("WSNNodesManager.jLabel12.text")); 
        jPanel4.add(jLabel12);
        jLabel12.setBounds(140, 70, 60, 30);

        jLabel11.setFont(jLabel11.getFont().deriveFont(jLabel11.getFont().getSize()+6f));
        jLabel11.setText(bundle.getString("WSNNodesManager.jLabel11.text")); 
        jPanel4.add(jLabel11);
        jLabel11.setBounds(140, 40, 90, 30);

        jLabel4.setFont(jLabel4.getFont().deriveFont(jLabel4.getFont().getSize()+6f));
        jLabel4.setText(bundle.getString("WSNNodesManager.jLabel4.text")); 
        jPanel4.add(jLabel4);
        jLabel4.setBounds(140, 10, 80, 23);

        jLabel10.setFont(jLabel10.getFont().deriveFont(jLabel10.getFont().getSize()+6f));
        jLabel10.setText(bundle.getString("WSNNodesManager.jLabel10.text")); 
        jPanel4.add(jLabel10);
        jLabel10.setBounds(20, 10, 110, 20);

        jLabel9.setFont(jLabel9.getFont().deriveFont(jLabel9.getFont().getSize()+6f));
        jLabel9.setText(bundle.getString("WSNNodesManager.jLabel9.text")); 
        jPanel4.add(jLabel9);
        jLabel9.setBounds(20, 70, 90, 30);

        jLabel8.setFont(jLabel8.getFont().deriveFont(jLabel8.getFont().getSize()+6f));
        jLabel8.setText(bundle.getString("WSNNodesManager.jLabel8.text")); 
        jPanel4.add(jLabel8);
        jLabel8.setBounds(20, 100, 90, 30);

        jLabel7.setFont(jLabel7.getFont().deriveFont(jLabel7.getFont().getSize()+6f));
        jLabel7.setText(bundle.getString("WSNNodesManager.jLabel7.text")); 
        jPanel4.add(jLabel7);
        jLabel7.setBounds(20, 130, 80, 30);

        jLabel6.setFont(jLabel6.getFont().deriveFont(jLabel6.getFont().getSize()+6f));
        jLabel6.setText(bundle.getString("WSNNodesManager.jLabel6.text")); 
        jPanel4.add(jLabel6);
        jLabel6.setBounds(140, 110, 60, 15);

        jLabel5.setFont(jLabel5.getFont().deriveFont(jLabel5.getFont().getSize()+6f));
        jLabel5.setText(bundle.getString("WSNNodesManager.jLabel5.text")); 
        jPanel4.add(jLabel5);
        jLabel5.setBounds(20, 40, 90, 30);

        jButton3.setFont(jButton3.getFont().deriveFont(jButton3.getFont().getSize()+6f));
        jButton3.setText(bundle.getString("WSNNodesManager.jButton3.text")); 
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton3);
        jButton3.setBounds(10, 170, 240, 31);

        jPanel3.add(jPanel4);
        jPanel4.setBounds(140, 40, 260, 210);

        jPanel5.setLayout(null);

        jButton2.setFont(jButton2.getFont().deriveFont(jButton2.getFont().getSize()+6f));
        jButton2.setText(bundle.getString("WSNNodesManager.jButton2.text")); 
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton2);
        jButton2.setBounds(20, 170, 260, 31);

        jComboBox5.setFont(jComboBox5.getFont().deriveFont(jComboBox5.getFont().getSize()+6f));
        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "1", "1.5", "2" }));
        jPanel5.add(jComboBox5);
        jComboBox5.setBounds(120, 130, 120, 30);

        jLabel14.setFont(jLabel14.getFont().deriveFont(jLabel14.getFont().getSize()+6f));
        jLabel14.setText(bundle.getString("WSNNodesManager.jLabel14.text")); 
        jPanel5.add(jLabel14);
        jLabel14.setBounds(10, 130, 110, 30);

        jComboBox3.setFont(jComboBox3.getFont().deriveFont(jComboBox3.getFont().getSize()+6f));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "NONE", "ODD", "EVEN", "MARK", "SPACE" }));
        jPanel5.add(jComboBox3);
        jComboBox3.setBounds(120, 100, 120, 29);

        jLabel15.setFont(jLabel15.getFont().deriveFont(jLabel15.getFont().getSize()+6f));
        jLabel15.setText(bundle.getString("WSNNodesManager.jLabel15.text")); 
        jPanel5.add(jLabel15);
        jLabel15.setBounds(10, 100, 110, 30);

        jComboBox2.setFont(jComboBox2.getFont().deriveFont(jComboBox2.getFont().getSize()+6f));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "50", "75", "110", "134", "150", "200", "300", "600", "1200", "1800", "2400", "4800", "9600", "19200", "38400", "57600", "115200", "230400", "460800", "921600" }));
        jComboBox2.setSelectedItem("115200");
        jPanel5.add(jComboBox2);
        jComboBox2.setBounds(120, 40, 120, 30);

        jComboBox1.setFont(jComboBox1.getFont().deriveFont(jComboBox1.getFont().getSize()+6f));
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9", "COM10", "COM11", "COM12", "COM13", "COM14", "COM15", "COM16", "COM17", "COM18", "COM19", "COM20", "COM21", "COM22", "COM23", "COM24", "COM25", "COM26", "COM27", "COM28", "COM29", "COM30", "COM31", "COM32", "COM33", "COM34", "COM35", "COM36", "COM37", "COM38", "COM39", "COM30", "COM31", "COM32", "COM33", "COM34", "COM35", "COM36", "COM37", "COM38", "COM39", "COM40", "COM41", "COM42", "COM43", "COM44", "COM45", "COM46", "COM47", "COM48", "COM49", "COM50", "COM51", "COM52", "COM53", "COM54", "COM55", "COM56", "COM57", "COM58", "COM59", "COM60", "COM61", "COM62", "COM63", "COM64", "COM65", "COM66", "COM67", "COM68", "COM69", "COM70", "COM71", "COM72", "COM73", "COM74", "COM75", "COM76", "COM77", "COM78", "COM79", "COM80", "COM81", "COM82", "COM83", "COM84", "COM85", "COM86", "COM87", "COM88", "COM89", "COM90", "COM91", "COM92", "COM93", "COM94", "COM95", "COM96", "COM97", "COM98", "COM99", "COM100", "COM101", "COM102", "COM103", "COM104", "COM105", "COM106", "COM107", "COM108", "COM109", "COM110", "COM111", "COM112", "COM113", "COM114", "COM115", "COM116", "COM117", "COM118", "COM119", "COM120", "COM121", "COM122", "COM123", "COM124", "COM125", "COM126", "COM127", "COM128", "COM129", "COM130", "COM131", "COM132", "COM133", "COM134", "COM135", "COM136", "COM137", "COM138", "COM139", "COM130", "COM131", "COM132", "COM133", "COM134", "COM135", "COM136", "COM137", "COM138", "COM139", "COM140", "COM141", "COM142", "COM143", "COM144", "COM145", "COM146", "COM147", "COM148", "COM149", "COM150", "COM151", "COM152", "COM153", "COM154", "COM155", "COM156", "COM157", "COM158", "COM159", "COM160", "COM161", "COM162", "COM163", "COM164", "COM165", "COM166", "COM167", "COM168", "COM169", "COM170", "COM171", "COM172", "COM173", "COM174", "COM175", "COM176", "COM177", "COM178", "COM179", "COM180", "COM181", "COM182", "COM183", "COM184", "COM185", "COM186", "COM187", "COM188", "COM189", "COM190", "COM191", "COM192", "COM193", "COM194", "COM195", "COM196", "COM197", "COM198", "COM199", "COM200", "COM201", "COM202", "COM203", "COM204", "COM205", "COM206", "COM207", "COM208", "COM209", "COM210", "COM211", "COM212", "COM213", "COM214", "COM215", "COM216", "COM217", "COM218", "COM219", "COM220", "COM221", "COM222", "COM223", "COM224", "COM225", "COM226", "COM227", "COM228", "COM229", "COM230", "COM231", "COM232", "COM233", "COM234", "COM235", "COM236", "COM237", "COM238", "COM239", "COM230", "COM231", "COM232", "COM233", "COM234", "COM235", "COM236", "COM237", "COM238", "COM239", "COM240", "COM241", "COM242", "COM243", "COM244", "COM245", "COM246", "COM247", "COM248", "COM249", "COM250", "COM251", "COM252", "COM253", "COM254", "COM255", " " }));
        jComboBox1.setSelectedItem("COM17");
        jPanel5.add(jComboBox1);
        jComboBox1.setBounds(120, 10, 120, 29);

        jComboBox4.setFont(jComboBox4.getFont().deriveFont(jComboBox4.getFont().getSize()+6f));
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "5", "6", "7", "8", "9" }));
        jComboBox4.setSelectedItem("8");
        jPanel5.add(jComboBox4);
        jComboBox4.setBounds(120, 70, 120, 29);

        jLabel16.setFont(jLabel16.getFont().deriveFont(jLabel16.getFont().getSize()+6f));
        jLabel16.setText(bundle.getString("WSNNodesManager.jLabel16.text")); 
        jPanel5.add(jLabel16);
        jLabel16.setBounds(10, 70, 110, 30);

        jLabel17.setFont(jLabel17.getFont().deriveFont(jLabel17.getFont().getSize()+6f));
        jLabel17.setText(bundle.getString("WSNNodesManager.jLabel17.text")); 
        jPanel5.add(jLabel17);
        jLabel17.setBounds(10, 10, 110, 20);

        jLabel18.setFont(jLabel18.getFont().deriveFont(jLabel18.getFont().getSize()+6f));
        jLabel18.setText(bundle.getString("WSNNodesManager.jLabel18.text")); 
        jPanel5.add(jLabel18);
        jLabel18.setBounds(10, 42, 110, 23);

        jPanel3.add(jPanel5);
        jPanel5.setBounds(440, 40, 300, 210);

        jPanel1.add(jPanel3);

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
    }

public int getListItemIndex3(String s){
   int inx=s.lastIndexOf("(");
   if(inx==-1){
     for(int i=0;i<listModel3.size();i++){
       if(wsn.getItemId((String)listModel3.get(i)).equals(s)) return i;
     }
    } else {
     for(int i=0;i<listModel3.size();i++){
       if(((String)listModel3.get(i)).equals(s)) return i;
     }
     }
    return -1;
}

private void formWindowClosing(java.awt.event.WindowEvent evt) {
  setVisible(false);
}

private void jList3MouseClicked(java.awt.event.MouseEvent evt) {
    changeListItem3();
}
public void setSelectedItem(String item){
    jList3.setSelectedValue(item,true);
    changeListItem3();
}
private void jList3KeyReleased(java.awt.event.KeyEvent evt) {
if(evt.getKeyCode()==38 || evt.getKeyCode()==40 )  changeListItem3();
}

private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {
    if(jList3.getSelectedValue()==null){
        JOptionPane.showMessageDialog(this, bundle2.getString("WSNNodesManager.xy.msg1")); return;
    } 
    if(jLabel21.getText().trim().length()<1){
        JOptionPane.showMessageDialog(this, bundle2.getString("WSNNodesManager.xy.msg2")); return;
    }
    if(jTextField3.getText().trim().length()<1 || Integer.parseInt((jTextField3.getText()))<1 || Integer.parseInt((jTextField3.getText()))>100){
        JOptionPane.showMessageDialog(this, bundle2.getString("WSNNodesManager.xy.msg3")); return;
    }
    String contCmd="performcommand WSN setmaxconnection "+jLabel21.getText().trim()+" "+jTextField3.getText()+" null null null null null null null null 0 0 0 0 ? ? ? 0";
    wsn.w.sendToOne(contCmd,wsn.getItemId((String)jList3.getSelectedValue()));
}

private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
    if(jList3.getSelectedValue()==null){
        JOptionPane.showMessageDialog(this, bundle2.getString("WSNNodesManager.xy.msg4")); return;
    } 
    if(jLabel21.getText().trim().length()<1){
        JOptionPane.showMessageDialog(this, bundle2.getString("WSNNodesManager.xy.msg5")); return;
    }
    String contCmd="performcommand WSN closesocketport "+jLabel21.getText().trim()+" null null null null null null null null 0 0 0 0 ? ? ? 0";
    wsn.w.sendToOne(contCmd,wsn.getItemId((String)jList3.getSelectedValue()));
}

private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {
    if(jList3.getSelectedValue()==null){
        JOptionPane.showMessageDialog(this, bundle2.getString("WSNNodesManager.xy.msg6")); return;
    } 
    if(jLabel21.getText().trim().length()<1){
        JOptionPane.showMessageDialog(this, bundle2.getString("WSNNodesManager.xy.msg7")); return;
    }
    if(jLabel27.getText().trim().length()<1){
        JOptionPane.showMessageDialog(this, bundle2.getString("WSNNodesManager.xy.msg8")); return;
    }
    int id=Integer.parseInt(jLabel27.getText().trim());
    if(id<1) {JOptionPane.showMessageDialog(this, bundle2.getString("WSNNodesManager.xy.msg9")); return;}
    String contCmd="performcommand WSN closesocketconnection "+jLabel21.getText().trim()+" "+jLabel27.getText().trim()+" null null null null null null null null 0 0 0 0 ? ? ? 0";
    wsn.w.sendToOne(contCmd,wsn.getItemId((String)jList3.getSelectedValue()));
}

private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {
    if(jList3.getSelectedValue()==null){
        JOptionPane.showMessageDialog(this, bundle2.getString("WSNNodesManager.xy.msg10")); return;
    } 
    if(jLabel4.getText().trim().length()<1){
        JOptionPane.showMessageDialog(this, bundle2.getString("WSNNodesManager.xy.msg11")); return;
    }
    String contCmd="performcommand WSN closeserialport "+jLabel4.getText().trim()+" null null null null null null null null 0 0 0 0 ? ? ? 0";
    wsn.w.sendToOne(contCmd,wsn.getItemId((String)jList3.getSelectedValue()));
}

private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
    if(jList3.getSelectedValue()==null){
        JOptionPane.showMessageDialog(this, bundle2.getString("WSNNodesManager.xy.msg12")); return;
    } 
    String comName=(String)jComboBox1.getSelectedItem();
    String bRate=(String)jComboBox2.getSelectedItem();
    String dataB=(String)jComboBox4.getSelectedItem();
    String parityB=(String)jComboBox3.getSelectedItem();
    String stopB=(String)jComboBox5.getSelectedItem();

    String contCmd="performcommand WSN openserialport "+comName+" "+bRate+" "+dataB+" "+parityB+" "+stopB+" null null null null null null null null 0 0 0 0 ? ? ? 0";
    wsn.w.sendToOne(contCmd,wsn.getItemId((String)jList3.getSelectedValue()));
}

private void socketPortListMouseClicked(java.awt.event.MouseEvent evt) {
 treat3_1();
}

private void serialPortListMouseClicked(java.awt.event.MouseEvent evt) {
  treat3_3();
}

private void serialPortListKeyReleased(java.awt.event.KeyEvent evt) {
if(evt.getKeyCode()==38 || evt.getKeyCode()==40 )  treat3_3();
}

private void socketPortListKeyReleased(java.awt.event.KeyEvent evt) {
if(evt.getKeyCode()==38 || evt.getKeyCode()==40 )  treat3_1();
}

private void connectionListKeyReleased(java.awt.event.KeyEvent evt) {
if(evt.getKeyCode()==38 || evt.getKeyCode()==40 )  treat3_2();
}

private void connectionListMouseClicked(java.awt.event.MouseEvent evt) {
  treat3_2();
}

private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {
    if(jList3.getSelectedValue()==null){
        JOptionPane.showMessageDialog(this, bundle2.getString("WSNNodesManager.xy.msg13")); return;
    } 
    String port=jTextField1.getText().trim();
    String maxCount=jTextField2.getText().trim();
    if(port.length()<1) {JOptionPane.showMessageDialog(this, bundle2.getString("WSNNodesManager.xy.msg14")); return;}
    if(maxCount.length()<1) {JOptionPane.showMessageDialog(this, bundle2.getString("WSNNodesManager.xy.msg15")); return;}

     String contCmd="performcommand WSN opensocketport "+port+" "+maxCount+" null null null null null null null null 0 0 0 0 ? ? ? 0";
     wsn.w.sendToOne(contCmd,wsn.getItemId((String)jList3.getSelectedValue()));
}
public void treat3_1(){
  if(socketPortList.getSelectedValue()!=null){
    String id=(String)socketPortList.getSelectedValue();  
    if(!id.equals(currentViewId3_1)){
       lastId3_1=currentViewId3_1;
      currentViewId3_1=id;
    }
    String contCmd="performmessage WSN getstatus3_1 "+currentViewId3_1+" null null null null null null null null 0 0 0 0 ? ? ? 0";
    wsn.w.sendToOne(contCmd,currentViewId3);
  }
}
public void treat3_2(){
    if(connectionList.getSelectedValue()!=null)      jLabel27.setText((String)connectionList.getSelectedValue());
}
public void treat3_3(){
    String id=(String)serialPortList.getSelectedValue();  
    if(!id.equals(currentViewId3_3)){
       lastId3_3=currentViewId3_3;
      currentViewId3_3=id;
    }
    String contCmd="performmessage WSN getstatus3_3 "+currentViewId3_3+" null null null null null null null null 0 0 0 0 ? ? ? 0";
    wsn.w.sendToOne(contCmd,currentViewId3);
}
public void changeListItem3(){
  String id=wsn.getItemId((String)jList3.getSelectedValue());

  if(id.length()>1){

  if(currentViewId3.length()>0){

    String lastId=currentViewId3;
    if(currentItemData3!=null && currentItemData3.length>2) currentItemData3[2]=wsn.w.getSsx(6,pid);
    if(currentItemData3!=null && currentItemData3.length>5) currentItemData3[5]="filler";
    if(currentItemData3!=null && currentItemData3.length>5 && currentItemData3[5].length()<1) currentItemData3[5]=currentItemData3[4];
    setItemData();
  }

  currentViewId3=id;
  currentItemData3=wsn.getItemData(id,3);
  if(id.equals("0")){
      skPortListModel.removeAllElements();
      connListModel.removeAllElements();
      srPortListModel.removeAllElements();
      jButton1.setEnabled(false);
      jButton2.setEnabled(false);
      jButton3.setEnabled(false);
      jButton4.setEnabled(false);
      jButton5.setEnabled(false);
      jButton6.setEnabled(false);
  } else {

  if(currentItemData3.length>0){};
  if(currentItemData3.length>4){};
  String showName=(currentItemData3!=null && currentItemData3.length>4? currentItemData3[4]:"");
  if(currentItemData3.length>5) {
     if(currentItemData3[5].length()>0) showName=currentItemData3[5]; else currentItemData3[5]=currentItemData3[4];
  }

  if(currentItemData3.length>2) {};
  if(currentItemData3.length>3 && currentItemData3[3].length()>0 && !wsn.w.checkOneVar(currentItemData3[1], 0)){
    String nData[]=wsn.getNodeData(currentItemData3[3]);
    currentItemData3[1]=wsn.w.addOneVar(currentItemData3[1],0);
    if(nData.length>5 && nData[5].length()>0) {
        if(currentItemData3!=null && currentItemData3.length>5) currentItemData3[5]=nData[5];

    }
    if(nData.length>2 && nData[2].length()>0) {
        if(currentItemData3!=null && currentItemData3.length>2) currentItemData3[2]=nData[2];

    }
  }

  String contCmd="performmessage WSN getstatus3 null null null null null null null null null 0 0 0 0 ? ? ? 0";
  wsn.w.sendToOne(contCmd,id);
  }
  }
}
public void setStatus3(String id,String stringx[]){
      if(socketPortList.getModel().getSize()>0 && socketPortList.getSelectedValue()!=null) lastId3_1=(String)socketPortList.getSelectedValue();
      else lastId3_1="";
      if(serialPortList.getModel().getSize()>0 && serialPortList.getSelectedValue()!=null) lastId3_3=(String)serialPortList.getSelectedValue();
      else lastId3_3="";
      currentViewStatus3=wsn.w.csvLineToArray(stringx[1]);
      skPortListModel.removeAllElements();
      connListModel.removeAllElements();
      srPortListModel.removeAllElements();
      int count=Integer.parseInt(currentViewStatus3[2]);
      int count2=Integer.parseInt(currentViewStatus3[4]);
          if(count>0){
            String tmp[]=wsn.w.csvLineToArray(currentViewStatus3[3]);
            String target="";
            for(int i=0;i<tmp.length;i++) skPortListModel.addElement(tmp[i]);
            if(lastId3.equals(currentViewId3) && lastId3_1.length()>0){
             int index = socketPortList.getNextMatch(lastId3_1,0,Position.Bias.Forward);
             if (index != -1) {
                 socketPortList.setSelectedValue(lastId3_1,true);
                 currentViewId3_1=lastId3_1;
             }
              else {socketPortList.setSelectedIndex(0); target=(String)socketPortList.getSelectedValue(); currentViewId3_1=target;}
            } else {socketPortList.setSelectedIndex(0); target=(String)socketPortList.getSelectedValue(); currentViewId3_1=target;}
              String contCmd="performmessage WSN getstatus3_1 "+currentViewId3_1+" null null null null null null null null null 0 0 0 0 ? ? ? 0";
            wsn.w.sendToOne(contCmd,currentViewId3);
          }
          if(count2>0){
            String tmp[]=wsn.w.csvLineToArray(currentViewStatus3[5]);
            String target="";
            for(int i=0;i<tmp.length;i++) srPortListModel.addElement(tmp[i]);
            if(lastId3.equals(currentViewId3) && lastId3_3.length()>0){
              int index = serialPortList.getNextMatch(lastId3_3,0,Position.Bias.Forward);
              if (index != -1) {
                  serialPortList.setSelectedValue(lastId3_3,true);
                  currentViewId3_3=lastId3_3;
              }
              else {serialPortList.setSelectedIndex(0); target=(String)serialPortList.getSelectedValue(); currentViewId3_3=target;}
            } else {serialPortList.setSelectedIndex(0); target=(String)serialPortList.getSelectedValue(); currentViewId3_3=target;}
              String contCmd="performmessage WSN getstatus3_3 "+currentViewId3_3+" null null null null null null null null null 0 0 0 0 ? ? ? 0";
              wsn.w.sendToOne(contCmd,currentViewId3);
          }
}
public void setStatus3_1(String id,String stringx[]){
      if(connectionList.getModel().getSize()>0 && connectionList.getSelectedValue()!=null) lastId3_2=(String)connectionList.getSelectedValue();
      else lastId3_2="";
      String tmp[]=wsn.w.csvLineToArray(stringx[1]);
      connListModel.removeAllElements();
        int maxCount=Integer.parseInt(tmp[1]);
        int count=Integer.parseInt(tmp[2]);
        jLabel21.setText(tmp[0]);
        jTextField3.setText(tmp[1]);
        jLabel25.setText(tmp[2]);
          if(count>0){
            String tmp2[]=wsn.w.csvLineToArray(tmp[3]);
            for(int i=0;i<tmp2.length;i++) connListModel.addElement(tmp2[i]);
            if(lastId3.equals(currentViewId3) && lastId3_1.equals(currentViewId3_1) && lastId3_2.length()>0){
             int index = connectionList.getNextMatch(lastId3_2,0,Position.Bias.Forward);
             if (index != -1) {
                 connectionList.setSelectedValue(lastId3_2,true);
                 currentViewId3_2=lastId3_2;
             }
              else {connectionList.setSelectedIndex(0); currentViewId3_2=(String)connectionList.getSelectedValue();}
            } else {connectionList.setSelectedIndex(0); currentViewId3_2=(String)connectionList.getSelectedValue();}
          } else currentViewId3_2="";
          jLabel27.setText(currentViewId3_2);

}

public void setStatus3_3(String id,String stringx[]){
    String tmp[]=wsn.w.csvLineToArray(stringx[1]);
    jLabel4.setText(tmp[0]);
    jLabel11.setText(tmp[1]);
    jLabel12.setText(tmp[2]);
    jLabel16.setText(tmp[3]);
    jLabel13.setText(tmp[4]);
}
private void setItemData(){
  boolean found=false;
  if(currentInnerMemberId3.length()>0){
      Object o=wsn.innerMemberItems.get(currentInnerMemberId3);
      if(o!=null){
        TreeMap tm=(TreeMap)o;
        if(tm.containsKey(currentViewId3)){
          tm.put(currentViewId3,wsn.w.arrayToCsvLine(currentItemData3));
          wsn.innerMemberItems.put(currentViewId3,tm);
        }
      }
    } else {
        Object o=wsn.outerMemberItems.get(currentViewId3);
        if(o!=null){
          wsn.outerMemberItems.put(currentViewId3,wsn.w.arrayToCsvLine(currentItemData3));
        }
  }
}

    private javax.swing.JList connectionList;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JComboBox jComboBox2;
    private javax.swing.JComboBox jComboBox3;
    private javax.swing.JComboBox jComboBox4;
    private javax.swing.JComboBox jComboBox5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    public javax.swing.JList jList3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JList serialPortList;
    private javax.swing.JList socketPortList;

}