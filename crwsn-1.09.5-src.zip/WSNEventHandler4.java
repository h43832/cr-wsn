
/**
 *
 * @author 850136
 */
public class WSNEventHandler4 extends WSNEventHandler{

}