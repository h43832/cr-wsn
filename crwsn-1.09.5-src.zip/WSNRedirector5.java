
/**
 *
 * @author 850136
 */
public class WSNRedirector5 extends WSNRedirector{

}