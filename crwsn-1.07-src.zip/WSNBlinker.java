import java.awt.*;
import java.util.*;
import infinity.client.*;
public class WSNBlinker extends Thread {
	WSN wsn=null;

	boolean onoff=true;
	long nextTime=0,nowTime=0,sleepTime=500;
	public WSNBlinker(WSN wsn){

		this.wsn=wsn;
	}
	public void run(){
          nextTime=System.currentTimeMillis();
	  while(true){
              nextTime=nextTime+sleepTime;
		try{

                    if(!wsn.isVisible() && wsn.props.getProperty("run_my_ap_only")!=null && wsn.props.getProperty("run_my_ap_only").equalsIgnoreCase("Y") && wsn.myAps.size()>0){
                        boolean foundActiveAp=false;
                        for(Iterator it = wsn.myAps.values().iterator(); it.hasNext(); ){
                          if(((WSNApplication)it.next()).isVisible()){foundActiveAp=true; break;}
                        }
                      if(!foundActiveAp) {wsn.w.ap.onExit(); wsn.onExit(); System.exit(0);}
                    }

                    for(Iterator it=wsn.myAps.values().iterator();it.hasNext();)  ((WSNApplication)it.next()).setBlink(onoff);
                    for(Enumeration en=wsn.lineCharts.elements();en.hasMoreElements();) ((WSNApplication)en.nextElement()).setBlink(onoff);
                     for(Enumeration en=wsn.eventHandlers.elements();en.hasMoreElements();) ((WSNApplication)en.nextElement()).setBlink(onoff);

		    if(onoff) onoff=false;
			else onoff=true;
                     nowTime=System.currentTimeMillis();
		     if(nextTime-nowTime>0) Thread.sleep(nextTime-nowTime);
                     else nextTime=nowTime;
		} catch (Exception e){
                     e.printStackTrace();
		  }
	  }
	}

}