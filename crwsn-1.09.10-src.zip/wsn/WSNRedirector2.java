package wsn;

/**
 *
 * @author 850136
 */
public class WSNRedirector2 extends WSNRedirector{

}