package wsn;

/**
 *
 * @author 850136
 */
public class WSNLineChart4 extends WSNLineChart{

}