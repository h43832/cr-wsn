package wsn;

/**
 *
 * @author 850136
 */
public class WSNLineChart5 extends WSNLineChart{

}