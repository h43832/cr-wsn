package wsn;

/**
 *
 * @author 850136
 */
public class WSNEventHandler2 extends WSNEventHandler{

}