package wsn;

/**
 *
 * @author 850136
 */
public class WSNEventHandler3 extends WSNEventHandler{

}