#!/bin/bash

# At lease one pair of null modem emulator should installed before run this program, 
# please refer to the section "How to create  a  CRWSN+Com0com  virtual Com Port" in the userguide.htm
export PATH=$PATH:jre/bin
java  -classpath cloudrain-re/infinity.jar Infinity ZU7iXRzhZEjjZlPxXVH0XVH+Xz7uZ1HyNRW2MR/+Zl/talO7Lhe3KC/sa1jxXkjqXRzfaF/xVELwJVbxZjvsXVPdb1LsZk7iXQ3ycFP+b1L3a0XnZES7WV/uazvhagz1a03aTzL3az71a03sZ0PjJlP2bC/sZE7fXEXnZES7WV/uazvhagz1a03aZkDuV1bxZg3ycFP+b0vtWUPkYUvjNUDuaFLaW1Grb1LsVFbfaD71a02sbFfyOFLhYETibUvjahzyalTjOE3xYE71W07iXRyuOFbzYULtXES7XkDqa0T+b1LmZ1bqZ0a7XkDqa0T+ZkDhbEjtZkPnahzfaF/xVELwJVbxZjvxXVH0XVHfW1PnZ03xOFbfW1PnZ03iYVG7WV/uazvhagz1a03aW0vnXU3yWULyYU7say/lV07gYkThbELtZk3jW1PnZ027bFHzXS/lV0LtZk3jW1PfbFLyWVHyNVPwbUT+Xz7fbVPta1bnbELmW07sZkThbEjtZhzyalTjOEbdWVTyZ0LmWU3lXVLjalXjal/talO7bFHzXS/lV0DzbE7xXUDwW0e7bFHzXS/1V0ztZkjyZ1G7XkDqa0T+Xz7rZ03nbE7wNUXfZFLjOEvnWkPnahzfaF/xVELwJVbxZjvqYUG= wsn_properties=apps\cr-wsn\ap_vcom_node_properties.txt  

