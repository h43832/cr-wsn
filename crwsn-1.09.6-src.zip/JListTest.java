import javax.swing.*;
import java.awt.*;
public class JListTest implements Runnable {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new JListTest());
    }

    @Override
    public void run() {
        JFrame frame = new JFrame(getClass().getSimpleName());
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(640, 480);
        frame.setLayout(new BorderLayout(4, 4));
        frame.add(getComponent(), BorderLayout.CENTER);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    Component getComponent() {
        DefaultListModel model = new DefaultListModel();
        model.addElement("one");
        model.addElement("two");
        model.addElement("three");

        JList list = new JList(model);
        list.setCellRenderer(new DefaultListCellRenderer());
        list.setVisible(true);
        return list;
    }
}