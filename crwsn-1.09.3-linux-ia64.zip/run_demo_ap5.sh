sh run_demo_ap5_1.sh &
sh run_demo_ap5_2.sh &
# start run_demo_ap5_3.sh &
# start run_demo_ap5_4.sh &
