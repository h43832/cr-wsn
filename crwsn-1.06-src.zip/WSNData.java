public interface WSNData {
    public double getValue(String data);
}