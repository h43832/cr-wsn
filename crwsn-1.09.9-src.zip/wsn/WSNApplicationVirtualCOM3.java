package wsn;

/**
 *
 * @author 850136
 */
public class WSNApplicationVirtualCOM3 extends WSNApplicationVirtualCOM{

}