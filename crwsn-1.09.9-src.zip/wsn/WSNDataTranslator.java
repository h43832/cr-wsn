package wsn;

public interface WSNDataTranslator {
    public double getValue(String data);
}