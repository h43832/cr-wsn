package wsn;

/**
 *
 * @author 850136
 */
public class WSNEventHandler5 extends WSNEventHandler{

}