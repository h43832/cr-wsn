package wsn;

/**
 *
 * @author 850136
 */
public class WSNLineChart3 extends WSNLineChart{

}