package wsn;

/**
 *
 * @author 850136
 */
public class WSNApplicationVirtualCOM4 extends WSNApplicationVirtualCOM{

}