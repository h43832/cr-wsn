
import java.io.*;
import java.awt.*;
import javax.swing.text.html.*;
import javax.swing.event.*;
import y.ylib.*;
public class WSNUsage extends javax.swing.JFrame implements HyperlinkListener{
  java.util.ResourceBundle bundle2;
    public WSNUsage() {
        initComponents();
        bundle2 = java.util.ResourceBundle.getBundle("Bundle"); 
        int width=Toolkit.getDefaultToolkit().getScreenSize().width;
        int h=Toolkit.getDefaultToolkit().getScreenSize().height-20;

        int w2=(width * 90000)/100000;
        int h2=(h * 90000)/100000;

        setSize(w2,h2);
        setTitle(bundle2.getString("WSNUsage.xy.msg1"));

        this.setVisible(true);
        setLocation((width-w2)/2,(h-h2)/2);
        setIconImage(Toolkit.getDefaultToolkit().createImage("apps"+File.separator+"cr-wsn"+File.separator+"crtc_logo7_transparent.gif"));
        jEditorPane1.setEditable(false);
        jEditorPane1.addHyperlinkListener(this);
    }
public void hyperlinkUpdate(HyperlinkEvent e){
    if(e.getEventType() == HyperlinkEvent.EventType.ACTIVATED)  { 
        

        String webAddr=e.getURL().toString();
         if(webAddr.indexOf("http")==-1){
             webAddr=webAddr.substring(5);
             webAddr=webAddr.replace('/', '\\');
             webAddr=(new File(webAddr)).getAbsolutePath();
             webAddr="file:///"+webAddr.replace('\\','/');
         }
          windowscommand2 wc2=new windowscommand2("start "+webAddr);
          wc2.start();

    }  
}
public void setPage(String page){
   try{
          jEditorPane1.setPage(page);
   }catch(IOException e){e.printStackTrace();}
}

    @SuppressWarnings("unchecked")

    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jEditorPane1 = new javax.swing.JEditorPane();

        jScrollPane1.setViewportView(jEditorPane1);

        getContentPane().add(jScrollPane1, java.awt.BorderLayout.CENTER);

        pack();
    }

    public static void main(String args[]) {

        

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(WSNUsage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(WSNUsage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(WSNUsage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(WSNUsage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new WSNUsage().setVisible(true);
            }
        });
    }

    private javax.swing.JEditorPane jEditorPane1;
    private javax.swing.JScrollPane jScrollPane1;

}